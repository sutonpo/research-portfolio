await Promise.all([
  import("./static/scripts/script-0-f7c52b6a.js"),
  import("./static/scripts/script-1-f1365b3a.js"),
  import("./static/scripts/script-2-4e3473f6.js"),
  import("./static/scripts/script-3-5ef560a8.js")
]);
await import("./static/scripts/script-4-51ee2d22.js");